//Navbar 
export const NAV_LINKS  = [
    { href: '/', key: 'home', label: 'Home' },
    { href: '/services', key: 'services', label: 'Services' },
    { href: '/about', key: 'about', label: 'About Us' },
    { href: '/career', key: 'career', label: 'Career' },
    { href: '/contacts', key: 'contacts', label: 'Contact Us' },
  ];
  // Business section 

export const businessData = {
  content: {
    heading: 'We are here to help',
    subheading: 'you grow your online',
    highlight: 'business',
  },
  styles: {
    container: 'flex flex-col items-center justify-center px-6 ml-14 mr-14 sm:px-14 h-[300px] bg-blue-600 rounded-md',
    heading: 'text-white text-2xl sm:text-4xl font-semibold text-center leading-snug tracking-wide',
    highlight: 'block',
    button: 'text-white border-2 border-white px-6 py-2 rounded-md font-medium transition-colors duration-300 hover:bg-blue-700 hover:text-white mt-4',
  },
};

//Features
 export const containerVariants = {
    hidden: { opacity: 0, y: 20 ,scale: 0.9},
    visible: { opacity: 1, y: 0,scale: 1, transition: { duration: 0.5,delay: 0.2 } },
     whileHover: { scale: 1.1 }
};

export  const itemVariants = {
    hidden: { opacity: 0, height: 0, transition: { duration: 0.3 } },
    visible: { opacity: 1, height: 'auto', transition: { duration: 0.3 } }
  };


//opportunity
 export  const inputVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.3 } }
  };

 export const buttonVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.6 } }
  };

export  const footerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.9 } }
  };
// Career page :  Header section

export const categories = [
  {
    name: "UX Designer",
    href: "/ux-designer",
  },
  {
    name: "Frontend Dev",
    href: "/frontend-dev",
  },
  {
    name: "Backend Dev",
    href: "/backend-dev",
  },
];
// Services page : services section 

 export const textVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
  };


// service page : Review section 

export const reviewData = [
  {
    value: "20K+",
    description: "Happy Clients"
  },
  {
    value: "5K+",
    description: "Successful Projects"
  },
  {
    value: "100+",
    description: "Positive Feedback"
  },
  {
    value: "50+",
    description: "Global Reach"
  },
];

// services page : brand section
export const brandImage = [
  "/Images/aliron-min.png",
  "/Images/fedex-min.png",
  "/Images/glycon-min.png",
  "/Images/aspiringminds-min.png",
  
];


// AboutUs page: Mission section

export const missionStats = {
  header: 'Our Mission',
  description: 'We are committed to delivering innovative IT solutions that empower businesses to achieve their goals and drive digital transformation. Our mission is to provide exceptional service and expertise to help our clients thrive in a rapidly evolving digital landscape.',
  imageSrc: '/Images/Our_mission-min.png',
  stats: [
    { value: '94%', label: 'Satisfaction Rate' },
    { value: '70M+', label: 'Users Served' },
    { value: '10K+', label: 'Projects Completed' }
  ]
};


// About page : vission section 

export const visionData = {
  title: 'Our Vision',
  description: 'Our vision is to become a leading innovator in the IT industry, providing cutting-edge solutions that drive growth and success for businesses worldwide. We aim to be recognized for our commitment to excellence, customer satisfaction, and our ability to adapt to the evolving technological landscape.',
  imageSrc: '/Images/our vision-min.jpg',
};


