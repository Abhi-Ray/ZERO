

export const footerContent = {
  logo: {
    src: "/Images/logo-min.png",
    alt: "Company Logo",
    companyName: "Vectrium Ventures",
    address: "Indore",
    email: "contact@vectriumventures.in",
    socialLinks: [
     
      { href: "https://www.linkedin.com/company/vectrium-ventures/?viewAsMember=true", icon: 'FaLinkedin', name: "LinkedIn" },
      { href: "https://wa.link/y841ch", icon: 'FaWhatsapp', name: "WhatsApp" },
      { href: "https://www.facebook.com/profile.php?id=61565679226049", icon: 'FaFacebookF', name: "Facebook" },
      { href: "https://www.instagram.com/vectrium_ventures/?hl=en", icon: 'FaInstagram', name: "Instagram" },
      // { href: "https://twitter.com", icon: 'FaTwitter', name: "Twitter" },
    ],
  },
  
  bottomLinks: {
    rights: "Copyright © 2025 | Vectrium Ventures | All Rights Reserved",
    policyLinks: [
      { href: "/terms", text: "Terms" },
      { href: "/privacy-policy", text: "Privacy Policy" },
      
    ],
  },
};
