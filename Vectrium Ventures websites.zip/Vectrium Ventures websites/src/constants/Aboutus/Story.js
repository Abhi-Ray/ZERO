// our story section 

export const storyData = {
    heading: "Vectrium Ventures is a premier IT solutions provider based in Indore, offering expertise in website development, UI/UX design, and digital marketing.",
    description: "We help businesses enhance their online presence with innovative strategies and tailored solutions, delivering high-quality results.",
    image: "/Images/blue1-min.webp",
    sections: [
      {
        title: "Client-Centric Innovation",
        description: "We focus on delivering personalized solutions, keeping the client’s goals at the forefront of every project. Our approach fosters long-term partnerships.",
        number: "01"
      },
      {
        title: "Strategic Expertise",
        description: "Backed by six years of research, we combine technical expertise with creative problem-solving to provide impactful IT solutions.",
        number: "02"
      },
      {
        title: "Collaborative Growth",
        description: "We work closely with our clients, ensuring seamless communication and collaboration, which helps us refine strategies and deliver results that exceed expectations.",
        number: "03"
      }
    ]
  };
  