// Services page : testimonial section

export const testimonials = [
  {
    heading: "Exceptional Service",
    quote: "The services provided by the team were beyond exceptional! We saw an incredible transformation.",
    name: "Rajesh Kumar",
    title: "CEO, TechSolutions Pvt. Ltd.",
    rating: 5,
  },
  {
    heading: "Fantastic Experience",
    quote: "A fantastic experience! Their attention to detail and customer service is unparalleled.",
    name: "Anita Patel",
    title: "Marketing Director, Innovate India",
    rating: 4,
  },
  {
    heading: "Outstanding Results",
    quote: "They went above and beyond to deliver an outstanding result. Our business has never been better!",
    name: "Sanjay Mehta",
    title: "Founder, Startup Ventures",
    rating: 5,
  },
  {
    heading: "Remarkable Effort",
    quote: "Their commitment to excellence is unparalleled. We saw significant growth and improvement.",
    name: "Pooja Sharma",
    title: "CTO, Future Innovations",
    rating: 4,
  },
  {
    heading: "Excellent Quality",
    quote: "The attention to detail and professionalism were evident throughout the project. Highly recommend!",
    name: "Ravi Singh",
    title: "Project Manager, DesignWorks",
    rating: 5,
  },
];
