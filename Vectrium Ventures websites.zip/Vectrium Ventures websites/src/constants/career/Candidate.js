import { FaCheckCircle, FaUserTie, FaCogs, FaBriefcase} from "react-icons/fa";

// Candidate section
export const boxData = [
    {
      icon: FaCheckCircle,
      title: "Profile",
      description: "Detailed information about the candidate’s background.",
      delay: 0,
    },
    {
      icon: FaUserTie,
      title: "Skills",
      description: "Showcasing the candidate’s key competencies and talents.",
      delay: 0.1,
    },
    {
      icon: FaCogs,
      title: "Experience",
      description: "Years of experience in relevant fields.",
      delay: 0.2,
    },
    {
      icon: FaBriefcase,
      title: "Portfolio",
      description: "Projects and work samples completed by the candidate.",
      delay: 0.3,
    },
  ];