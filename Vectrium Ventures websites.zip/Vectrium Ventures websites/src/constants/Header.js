// Header section 
export const headerData = {
    heading: {
      main: 'Empowering Your',
      sub: 'Digital Journey',
      highlight: 'with Innovative',
      last: 'IT Solutions',
    },
    description: [
      'Vectrium Ventures delivers tailored IT solutions that elevate',
      'your brand and streamline your digital operations.',
      'Our expert team specializes in driving innovation',
      'across design, development, and marketing.',
    ],
    button: {
      text: 'Call Now',
      icon: 'FaLongArrowAltRight',
      link: 'https://wa.link/y841ch'
    },
    styles: {
      container: 'flex flex-col items-start justify-center h-screen p-8 md:ml-40 sm:p-6 xs:p-4',
      heading: 'text-4xl md:text-5xl lg:text-6xl font-bold mb-4 leading-relaxed',
      description: 'text-base md:text-lg mb-6',
      button: 'bg-blue-600 text-white px-8 py-2 font-semibold rounded-md flex items-center text-sm md:text-md transition-transform transform hover:scale-105 hover:bg-blue-700 focus:outline-none',
    },
  };