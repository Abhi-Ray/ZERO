
import { FaLaptopCode, FaPaintBrush, FaDesktop, FaBullhorn, FaFacebookF, FaBusinessTime, FaPenFancy, FaDigitalTachograph} from "react-icons/fa";
//services
export const services = [
    {
      title: "Website Development",
      description: "Our website development service focuses on creating dynamic and interactive websites that are not only visually appealing but also functional and user-friendly.",
      route: "/website-development",
      icon: FaLaptopCode 
    },
    {
      title: "Graphic Designing",
      description: "Graphic designing is at the heart of building a strong brand identity. Our graphic design services include everything from logo creation and branding materials to marketing collateral and digital graphics.",
      route: "/graphic-designing",
      icon: FaPaintBrush
    },
    {
      title: "UI/UX Web Designing",
      description: "UI/UX design is crucial for creating intuitive and enjoyable user experiences. Our UI/UX web designing service focuses on designing user interfaces that are not only aesthetically pleasing but also easy to navigate.",
      route: "/ui-ux-web-designing",
      icon: FaDesktop
    },
    {
      title: "Brand Building",
      description: "Brand building is essential for establishing a strong market presence. Our brand building services involve developing comprehensive strategies to enhance your brand’s visibility and reputation.",
      route: "/brand-building",
      icon: FaBullhorn
    },
    {
      title: "Social Media Handling",
      description: "In the digital age, effective social media handling is key to engaging with your audience and growing your online presence. Our social media handling service includes managing your social media profiles,  and implementing strategies to boost engagement and drive traffic.",
      route: "/social-media-handling",
      icon: FaFacebookF
    },
    {
      title: "Business Consultation",
      description: "Our business consultation services provide expert guidance to help you make informed decisions and drive growth. We offer strategic advice on various aspects of your business, including operations, marketing, and financial planning.",
      route: "/business-consultation",
      icon: FaBusinessTime
    },
    {
      title: "SEO and Content Writing",
      description: "SEO and content writing are critical for enhancing your website’s visibility and attracting the right audience.",
      route: "/seo-content-writing",
      icon: FaPenFancy
    },
    {
      title: "Digital Marketing",
      description: "Digital marketing encompasses a range of strategies to promote and grow your business online. Our digital marketing services include creating and managing campaigns across various digital channels, such as search engines, social media, and email.",
      route: "/digital-marketing",
      icon: FaDigitalTachograph
    }
  ];
