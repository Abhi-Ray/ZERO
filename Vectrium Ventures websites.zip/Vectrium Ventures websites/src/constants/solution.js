// Solution section 
export const solutionsData = {
  meta: {
   
    description: 'Discover the range of IT solutions offered by Vectrium Ventures to drive your business growth and success.',
    keywords: 'IT solutions, website development, graphic designing, UI/UX web designing, brand building, social media handling, business consultation, SEO, digital marketing'
  },
  image: {
    src: '/Images/solutions-min.png',
    alt: 'Solution Image',
  },
  content: {
    heading: 'Our Solutions',
    description: `Vectrium Ventures is a leading IT solution service provider based in Indore. Our company specializes in a range of services including website development, graphic designing, UI/UX web designing, brand building, social media handling, business consultation, SEO and content writing, and digital marketing.`,
  },
  styles: {
    container: 'flex flex-col lg:flex-row items-center lg:items-center max-container px-6 py-20 space-y-10 lg:space-y-0 lg:space-x-10',
    imageContainer: 'w-full lg:w-1/2 flex justify-center',
    image: 'rounded-xl shadow-lg object-cover w-full max-w-[600px]',
    contentContainer: 'w-full lg:w-1/2 text-center lg:text-left flex justify-center lg:justify-start',
    contentWrapper: 'max-w-full lg:max-w-[500px]',
    heading: 'text-3xl sm:text-4xl font-bold text-gray-800 mb-4',
    description: 'text-base sm:text-lg text-gray-600',
  },
};
