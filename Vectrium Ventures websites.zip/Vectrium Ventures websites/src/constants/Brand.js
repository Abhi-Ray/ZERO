
  //  brand 
  export const brandImages = [
    "/Images/kindle-fire-logo-min.png",
    "/Images/donnelly-logo-min.png",
    "/Images/imation-logo.webp",
    "/Images/glycon-min.png",
    "/Images/kanrar-min.jpg",
    "/Images/lesechos-logo-min.png",
  ];
  
  export  const brandImages1 = [
    "/Images/franchise.webp",
    "/Images/aliron-min.png",
    "/Images/aspiringminds-min.png",
    "/Images/fedex-min.png",
    "/Images/grow-min.jpg",
    "/Images/thrive-min.png",
  ];