import { Helmet } from 'react-helmet';
import { FaLongArrowAltRight } from 'react-icons/fa'; // Correct import for the button icon
import { motion } from 'framer-motion'; 
import React from 'react';
import { headerData } from "../constants/Header"; // Ensure this import path is correct

const Header = () => {
  // Destructure headerData with default values
  const {
    heading = {},
    description = [],
    button = {},
    styles = {},
  } = headerData || {};

  return (
    <div>
      <Helmet>
        <title>{headerData.seo?.title || "Welcome to Vectrium Ventures"}</title>
        <meta name="description" content={headerData.seo?.description || "Discover the best services offered by Vectrium Ventures"} />
        <meta name="keywords" content={headerData.seo?.keywords || "vectrium, ventures, services, technology, business"} />
      </Helmet>

      <motion.div
        className={styles.container}
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <motion.h1
          className={styles.heading}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {heading.main} <br className="hidden sm:inline mb-4" />
          <span className="text-blue-600">{heading.sub}</span><br className="hidden sm:inline mb-4" />
          {heading.highlight} <br className="hidden sm:inline mb-4" />
          {heading.last}
        </motion.h1>

        <motion.p
          className={styles.description}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          {description.map((line, index) => (
            <React.Fragment key={index}>
              {line} <br className="hidden sm:inline" />
            </React.Fragment>
          ))}
        </motion.p>

        <motion.a
          href={button.link}
          className={styles.button}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          transition={{ duration: 0.3 }}
        >
          {button.text}
          <FaLongArrowAltRight className="ml-2 transition-transform transform" />
        </motion.a>
      </motion.div>
    </div>
  );
};

export default Header;
