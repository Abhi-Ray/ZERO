import { motion } from 'framer-motion';
import Navbar from "../Navbar";
import { Category } from "./Categories"; 
import Candidate from "./Candidate";
import CareerForm from "./CareerForm";
import Footer from "../Footer";

import { categories } from '../../constants';
import { Helmet } from 'react-helmet';

const Career = () => {
  return (
    <div>
     <Helmet>
  <title>Career Opportunities | Vectrium Ventures</title>
  <meta name="description" content="Explore exciting career opportunities at Vectrium Ventures, a leading IT solutions provider. Learn about our job openings, dynamic company culture, and how you can join our innovative team in areas like website development, graphic designing, UI/UX, and digital marketing." />
  <meta name="keywords" content="Vectrium Ventures Careers, Job Openings, IT Jobs Indore, Website Development Careers, Graphic Design Jobs, UI/UX Jobs, Digital Marketing Jobs, Career Opportunities, Join Vectrium Ventures" />
</Helmet>


      {/* Add Navbar */}
      <Navbar />

      <div
        className="min-h-screen bg-cover bg-center bg-no-repeat"  
        style={{ backgroundImage: "url('/Images/bg-img-3-min.jpg')" }}
      >
        <div className="flex flex-col items-center md:items-start justify-center md:justify-start min-h-[calc(100vh-4rem)] p-8 md:p-16">
          <motion.div
            className="max-w-lg w-full mt-20"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-black mb-4 leading-tight tracking-wider">
              One Step <br className="hidden sm:inline" />
              Closer To Your <br className="hidden sm:inline" />
              New Job
            </h1>
            <p className="text-base md:text-lg text-black mb-8">
              Explore exciting career opportunities at Vectrium Ventures. We are
              always looking for talented individuals to join our team and help us
              grow. If you’re passionate about technology, creativity, and
              innovation, we’d love to hear from you.
            </p>

            {/* Popular Categories Section */}
            <div className="mb-6">
              <h2 className="text-xl md:text-2xl font-semibold text-black mb-4">
                Popular Categories
              </h2>
              <div className="flex flex-wrap gap-4 justify-center">
                {/* Map through the categories array */}
                {categories.map((category) => (
                  <a
                    key={category.href}
                    href={category.href}
                    className="bg-blue-600 text-white px-4 py-2 rounded-full font-medium hover:bg-blue-700"
                  >
                    {category.name}
                  </a>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Categories Section */}
      <motion.div
        className="p-8 md:p-16"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 2 }}
      >
        <Category />
      </motion.div>

      {/* Candidate section */}
      <motion.div
        className="p-8 md:p-16"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 2.5 }}
      >
        <Candidate />
      </motion.div>

      {/* Career Form section */}
      <motion.div
        className="p-8 md:p-16"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 3 }}
      >
        <CareerForm />
      </motion.div>

      {/* Footer Section */}
      <div className="lg:block">
        <Footer />
      </div>
    </div>
  );
};

export default Career;
