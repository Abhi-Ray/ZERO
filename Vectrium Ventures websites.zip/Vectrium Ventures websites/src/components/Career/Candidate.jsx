import { motion } from 'framer-motion';
import { boxData } from "../../constants/career/Candidate";
import MobileCandidate from './MobileCandidate';
import { Helmet } from 'react-helmet';

const Candidate = () => {
  return (
    <div className="relative">
       <Helmet>
  
  <meta name="description" content="View and manage your candidate profile with Vectrium Ventures. Update your information and track your application status as you explore career opportunities with us." />
</Helmet>
      <div className="hidden lg:flex lg:flex-row p-8">
        <div className="w-full lg:w-1/2 flex justify-center lg:justify-start">
          <motion.img  loading="lazy"
            src="/Images/career-min.jpg" 
            alt="Candidate Image"
            className="rounded-lg shadow-lg w-full lg:w-3/4 object-cover"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            whileHover={{ scale: 1.05, boxShadow: "0 8px 16px rgba(0,0,0,0.2)" }}
          />
        </div>

        <div className="w-full lg:w-1/2 lg:pl-12 mt-8 lg:mt-0">
          <h2 className="text-3xl font-bold mb-6">
            Perfect for Candidates.<br className="hidden sm:inline" />
            Beautiful for Employers.
          </h2>

          {/* Boxes container */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {boxData.map((box, index) => (
              <motion.div
                key={index}
                className="bg-white shadow-md rounded-lg p-4 flex items-start hover:bg-blue-50 transition-colors duration-300"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: box.delay }}
                whileHover={{ scale: 1.05, boxShadow: "0 8px 16px rgba(0,0,0,0.2)" }}
              >
                <box.icon className="text-blue-600 text-2xl mr-4" />
                <div>
                  <h3 className="font-bold text-xl">{box.title}</h3>
                  <p className="text-gray-600">{box.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Mobile View */}
      <div className="lg:hidden">
        <MobileCandidate />
      </div>
    </div>
  );
};

export default Candidate;
