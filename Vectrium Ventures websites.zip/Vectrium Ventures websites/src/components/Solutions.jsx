import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet'; 
import { solutionsData } from '../constants/solution'; 

const Solutions = () => {
  return (
    <>
      <Helmet>
        
        <meta name="description" content={solutionsData.meta.description || 'Discover the range of IT solutions offered by Vectrium Ventures to drive your business growth and success.'} />
        <meta name="keywords" content={solutionsData.meta.keywords || 'IT solutions, website development, graphic designing, UI/UX web designing, brand building, social media handling, business consultation, SEO, digital marketing'} />
      </Helmet>
      
      <div className={solutionsData.styles.container}>
        <motion.div
          className={solutionsData.styles.imageContainer}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          whileHover={{ scale: 1.05 }}
        >
          <img loading="lazy"
            src={solutionsData.image.src}
            alt={solutionsData.image.alt}
            className={solutionsData.styles.image}
          />
        </motion.div>

        <motion.div
          className={solutionsData.styles.contentContainer}
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <div className={solutionsData.styles.contentWrapper}>
            <h1 className={solutionsData.styles.heading}>
              {solutionsData.content.heading}
            </h1>
            <p className={solutionsData.styles.description}>
              {solutionsData.content.description}
            </p>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default Solutions;
