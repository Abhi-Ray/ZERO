import { Helmet } from 'react-helmet';
const DropdownContent = ({ activeIndex }) => {
  const content = {
    1: "Brand Building: We help you establish a strong and recognizable brand presence.",
    2: "Social Media Handling: Our strategies boost your online presence and engage your audience.",
    3: "Business Consultation: Expert advice to guide your business towards growth and success.",
   
  };

  return (
    <div
      className={`mt-2 p-4 bg-gray-100 border border-gray-300 rounded-lg shadow-md w-full sm:w-[500px] md:w-[1000px] max-w-full transition-transform ${
        activeIndex ? 'animate-slideDown' : 'hidden'
      }`}
    >
      <Helmet>
  <title>Dropdown Content | Vectrium Ventures</title>
  <meta name="description" content="Discover the comprehensive dropdown features of Vectrium Ventures, offering detailed insights into our services, solutions, and IT expertise for your business growth." />
</Helmet>

      <p>{content[activeIndex]}</p>
    </div>
  );
};

export default DropdownContent;
