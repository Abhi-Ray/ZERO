import { motion } from 'framer-motion';
import { businessData } from '../constants'; 
import { Helmet } from 'react-helmet';

const Business = () => {
  return (
    <div>
      <Helmet>
 
  <meta name="description" content="Vectrium Ventures offers strategic business solutions to help you grow and manage your online presence, including web development, branding, SEO, and digital marketing services." />
</Helmet>

    <motion.div
      className={businessData.styles.container}
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      whileHover={{ scale: 1.05 }}
    >
      <h1 className={businessData.styles.heading}>
        {businessData.content.heading}
        <br className="hidden sm:inline" />
        {businessData.content.subheading}
        <br className="hidden sm:inline" />
        <span className={businessData.styles.highlight}>{businessData.content.highlight}</span>
      </h1>

      {/* Call Now Button */}
      <motion.a
        href="https://wa.link/y841ch" 
        className={businessData.styles.button}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        Call Now
      </motion.a>
    </motion.div>
    </div>
  );
};

export default Business;
