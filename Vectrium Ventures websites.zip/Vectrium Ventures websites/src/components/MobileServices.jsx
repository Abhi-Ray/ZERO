import { Helmet } from 'react-helmet';
import { FaLongArrowAltRight, FaLongArrowAltLeft } from "react-icons/fa";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Card, CardContent } from "@/components/ui/card";
import { services } from "../constants/Services";
import React from 'react';
import { motion } from 'framer-motion';
import { useEffect, useRef } from 'react';


const MobileServices = () => {
  const carouselRef = useRef(null);  
  const nextButtonRef = useRef(null); 

  
  useEffect(() => {
    const interval = setInterval(() => {
      if (nextButtonRef.current) {
        nextButtonRef.current.click(); 
      }
    }, 3000);  

    return () => clearInterval(interval); 
  }, []);

  return (
    <div className="w-full min-h-screen  flex flex-col items-center">
      <Helmet>
        <meta name="description" content="Explore the services offered by Vectrium Ventures, including web development, graphic design, and more." />
      </Helmet>
      
      <motion.h1 
        className="text-3xl sm:text-4xl font-bold text-center mb-12"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        Services Offered by Us
      </motion.h1>

     
      <Carousel
       ref={carouselRef}
        opts={{
          align: "center",
          itemsToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          loop: true 
        }}
        className="w-full max-w-2xl sm:max-w-3xl mx-auto relative mt-12 px-4 sm:px-0"
      >
        <CarouselContent className="flex gap-4">
          {services.map((service, index) => (
            <CarouselItem 
              key={index} 
              className="flex-none w-full flex justify-center"
            >
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, ease: "easeInOut" }}
                className="w-full max-w-sm sm:max-w-md"
              >
                <Card className="bg-white shadow-md rounded-lg transition-transform transform hover:scale-95">
                  <CardContent className="relative flex flex-col items-center p-6 space-y-4">
                    <div className="flex flex-col items-center space-y-4">
                     
                      <div className="w-16 h-16 sm:w-20 sm:h-20 flex bg-blue-100 items-center justify-center rounded-full border-4 border-blue-600 shadow-lg">
                        <motion.div
                          initial={{ opacity: 0, rotate: -10 }}
                          animate={{ opacity: 1, rotate: 0 }}
                          transition={{ duration: 0.5, ease: "easeInOut" }}
                          className="flex items-center justify-center w-full h-full"
                        >
                         
                          {React.createElement(service.icon, {
                            className: "text-blue-600 w-8 h-8 sm:w-10 sm:h-10",
                          })}
                        </motion.div>
                      </div>
                      
                      <div className="text-center">
                        <h2 className="text-md sm:text-lg font-bold text-gray-800">{service.title}</h2>
                        <p className="text-sm text-gray-600 mt-2">
                          {service.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </CarouselItem>
          ))}
        </CarouselContent>

        <CarouselPrevious className="hidden">
          <FaLongArrowAltLeft className="w-5 h-5" />
        </CarouselPrevious>
        <CarouselNext 
          ref={nextButtonRef} 
        className=" hidden">
          <FaLongArrowAltRight className="w-5 h-5" />
        </CarouselNext>
      </Carousel>
    </div>
  );
};

export default MobileServices;
