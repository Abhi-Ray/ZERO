import { motion } from "framer-motion";
import {brandImages, brandImages1} from "../constants/Brand";
import { Helmet } from 'react-helmet';

const Brands = () => {

return (
    <div className="p-4 sm:p-8">
      <Helmet>
 
  <meta name="description" content="Build a strong brand with Vectrium Ventures. Our brand building services include logo design, brand strategy, and social media management to enhance your online presence." />
</Helmet>

      <h2 className="text-2xl sm:text-3xl font-bold mb-6 text-center mt-10">
        Trusted by Leading Brands
      </h2>
      
      <div className="flex flex-wrap gap-4 justify-center">
        {brandImages.map((brand, index) => (
          <motion.div
            key={index}
            className="bg-white border border-slate-200 p-4 rounded-md shadow-md flex-1 min-w-[120px] text-center"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ scale: 1.05, boxShadow: "0 10px 20px rgba(0, 0, 0, 0.2)" }}
          >
            <img loading="lazy" src={brand} alt={`Brand ${index}`} className="mx-auto h-16 sm:h-24" />
          </motion.div>
        ))}
      </div>
      
      <div className="flex flex-wrap gap-4 mt-8 justify-center">
        {brandImages1.map((brand, index) => (
          <motion.div
            key={index}
            className="bg-white border border-slate-200 p-4 rounded-md shadow-md flex-1 min-w-[120px] text-center"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ scale: 1.05, boxShadow: "0 10px 20px rgba(0, 0, 0, 0.2)" }}
          >
            <img loading="lazy" src={brand} alt={`Brand ${index}`} className="mx-auto h-16 sm:h-24" />
          </motion.div>
        ))}
      </div>
     

    </div>
  );
};

export default Brands;
