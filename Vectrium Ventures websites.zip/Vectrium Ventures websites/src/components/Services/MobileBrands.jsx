import { motion } from "framer-motion";
import { brandImage } from "../../constants";
import { Helmet } from 'react-helmet';
const MobileBrands = () => {
  return (
    <div className="py-8 px-4">
      <Helmet>
  
  <meta name="description" content="Explore the reputable brands we work with at Vectrium Ventures, showcasing our partnerships and the quality of our IT and digital solutions." />
</Helmet>

      <div className="max-w-md mx-auto">
        <div className="flex flex-wrap justify-center gap-4">
          {brandImage.map((brand, index) => (
            <motion.img loading="lazy"
              key={index}
              src={brand}
              alt={`Brand ${index + 1}`}
              className="h-12 w-auto object-contain"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1, ease: "easeInOut" }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default MobileBrands;
