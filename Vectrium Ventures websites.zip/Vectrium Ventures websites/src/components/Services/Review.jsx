import { motion } from 'framer-motion';
import { reviewData,containerVariants  } from '../../constants'; 
import { Helmet } from 'react-helmet';

const Review = () => {
  
   return (
    <div>
      <Helmet>
  
  <meta name="description" content="Read what our satisfied clients have to say about their experiences with Vectrium Ventures' top-notch services in IT solutions, digital marketing, and more." />
</Helmet>

    <motion.div
      className="hidden md:flex justify-around items-center py-12 bg-gray-50"
      initial="hidden"
      animate="visible"
    >
      {reviewData.map((item, index) => (
        <motion.div
          key={index}
          variants={containerVariants}
          whileHover="whileHover"
          className="text-center"
        >
          <h1 className="text-4xl font-bold text-blue-800">{item.value}</h1>
          <p className="text-gray-600 mt-2">{item.description}</p>
        </motion.div>
      ))}
    </motion.div>
    </div>
  );
};

export default Review;
