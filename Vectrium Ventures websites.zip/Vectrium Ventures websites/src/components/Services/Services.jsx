import { motion } from "framer-motion";
import Brands from './Brands';
import Navbar from "../Navbar";
import AllServices from "./AllServices";
import Review from './Review';
import Testimonial from "./Testimonial";
import Footer from "../Footer";
import MobileServices from "./MobileServices";  
import MobileReview from "./MobileReview";

import MobileBrands from "./MobileBrands";

import {textVariants} from "../../constants";
import { Helmet } from 'react-helmet';
const Services = () => {
  
  return (
    <div>
    <Helmet>
  <title>Our Services | Vectrium Ventures</title>
  <meta name="description" content="Explore the wide range of services offered by Vectrium Ventures, including website development, graphic design, UI/UX design, SEO, digital marketing, and business consultation to help grow your brand." />
  <meta name="keywords" content="Vectrium Ventures Services, Website Development, Graphic Design, UI/UX Design, SEO Services, Digital Marketing, Business Consultation, IT Solutions, Branding Services" />
</Helmet>

    <Navbar />
      <motion.div
        className="hidden md:block min-h-screen bg-cover bg-center bg-no-repeat" loading="lazy"
        style={{ backgroundImage: "url('/Images/bg-img-3-min.jpg')" }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        
        <div className="p-8 max-w-4xl mx-auto text-left ml-36 mt-16 ">
          <div className="max-w-2xl mt-12">
           
            <motion.h2
              className="text-lg font-semibold text-gray-800 mb-2"
              variants={textVariants}
              initial="hidden"
              animate="visible"
            >
              Our Services
            </motion.h2>
            
          
            <motion.h1
              className="text-4xl font-bold text-blue-800 mb-6 leading-tight tracking-wider"
              variants={textVariants}
              initial="hidden"
              animate="visible"
              transition={{ delay: 0.2 }}
            >
              We provide best <br className="hidden sm:inline" />
              business solutions
            </motion.h1>

           
            <motion.p
              className="text-lg text-gray-700 mb-8"
              variants={textVariants}
              initial="hidden"
              animate="visible"
              transition={{ delay: 0.4 }}
            >
              We provide a range of services designed to help <br className="hidden sm:inline" />
              your business grow. From innovative design solutions <br className="hidden sm:inline" />
              to cutting-edge technology and strategic marketing, <br className="hidden sm:inline" />
              our team is dedicated to delivering high-quality <br className="hidden sm:inline" />
              results tailored to your needs.
            </motion.p>

            {/* Button animations */}
            <motion.div
              className="flex space-x-4"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6, duration: 0.5 }}
            >
              <a 
                href="https://wa.link/y841ch" 
                className="flex items-center justify-center px-6 py-3 bg-blue-600 w-40 h-11 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition duration-300 transform hover:scale-105"
              >
                Call Now
              </a>
             
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* Mobile Services Section */}
      <motion.div
        className="block md:hidden bg-white"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <MobileServices />
      </motion.div>

      {/* All Services*/}
      <motion.div
        className="bg-blue-100"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <AllServices />
      </motion.div>

      {/* Review section */}
      <motion.div
        className="block md:hidden bg-white"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <MobileReview />
      </motion.div>
      <motion.div
        className="bg-blue-100"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Review />
      </motion.div>

      {/* Testimonials Section */}
      <motion.div
        className=" bg-white"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Testimonial />
      </motion.div>
     
     {/* Brands */}
      <motion.div
        className="bg-white"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Brands />
      </motion.div>
      <motion.div
        className="block md:hidden bg-white"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <MobileBrands />
      </motion.div>

     

      {/* Footer */}
      <motion.div
        className=" lg:block bottom-0 left-0 right-0 text-white p-4 justify-around rounded-lg"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Footer />
      </motion.div>
     
    </div>
  );
};

export default Services;
