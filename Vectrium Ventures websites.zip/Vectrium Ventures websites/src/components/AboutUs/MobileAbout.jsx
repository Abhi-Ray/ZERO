import { motion } from 'framer-motion';
import Navbar from '../Navbar'; 
import { Helmet } from 'react-helmet';
const MobileAbout = () => {
  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat" 
      style={{ backgroundImage: "url('/Images/bg-img-3-min.jpg')" }}
    >
      <Helmet>
  <title>About Us | Vectrium Ventures</title>
  <meta name="description" content="Learn more about Vectrium Ventures, a leading IT solution service provider in Indore, specializing in website development, graphic designing, and more. Explore our values, team, and commitment to excellence." />
</Helmet>

      {/* Navbar Section */}
      <Navbar />
      
      <motion.div
        className="flex flex-col justify-center items-center h-full pt-20 px-6 text-center mt-16"
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-black mb-8 mt-16">
          We’re changing the 
          <br />
          <span className="mt-2 block">whole game.</span>
        </h1>

        {/* Mobile Buttons */}
        <div className="flex flex-col items-center space-y-4 w-full max-w-xs">
          <a href="https://wa.link/y841ch" className="flex justify-center">
            <motion.button
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-full"
              whileHover={{ scale: 1.05 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              Call Now
            </motion.button>
          </a>
        </div>
      </motion.div>
    </div>
  );
};

export default MobileAbout;
