import { motion } from 'framer-motion';
import { missionStats } from '../../constants'; 
import { Helmet } from 'react-helmet';
const Mission = () => {
  return (
    <div className="py-8 mt-16">
       <Helmet>
  
  <meta name="description" content="Discover Vectrium Ventures' mission to provide innovative IT solutions, drive technological advancements, and deliver unparalleled value to our clients through dedication and expertise." />
</Helmet>
      <div className="container mx-auto px-4 flex flex-col lg:flex-row gap-8">
        {/* Left Container */}
        <motion.div
          className="lg:w-1/2 flex flex-col justify-center bg-white p-6 lg:p-8"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-black mb-6 lg:mb-8">
            {missionStats.header}
          </h1>
          <p className="text-gray-600 text-base md:text-lg leading-[1.75] lg:leading-[2.0] mb-6 lg:mb-8">
            {missionStats.description}
          </p>
          {/* Statistics */}
          <div className="flex flex-col sm:flex-row justify-between md:space-x-10 lg:space-x-36">
            {missionStats.stats.map((stat, index) => (
              <motion.div
                key={index}
                className="text-center mb-6 sm:mb-0"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: stat.delay }}
              >
                <h2 className="text-4xl md:text-5xl font-bold text-black">
                  {stat.value}
                </h2>
                <p className="text-gray-600 text-sm md:text-base">
                  {stat.label}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Right Container */}
        <motion.div
          className="lg:w-1/2 flex items-center justify-center bg-white p-6 lg:p-8"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <motion.img loading="lazy"
            src={missionStats.imageSrc}
            alt="Mission Image"
            className="w-full h-auto object-cover rounded-xl"
            whileHover={{ scale: 1.05 }}
            transition={{ type: 'spring', stiffness: 300 }}
          />
        </motion.div>
      </div>
    </div>
  );
};

export default Mission;
