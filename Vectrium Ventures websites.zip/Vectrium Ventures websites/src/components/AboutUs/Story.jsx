import { motion } from 'framer-motion';
import { storyData } from '../../constants/Aboutus/Story'; 
import { Helmet } from 'react-helmet';
const Story = () => {
  return (
    <div className="relative py-12 md:py-16 mt-12 md:mt-20">
      <Helmet>
 
  <meta name="description" content="Explore the story behind Vectrium Ventures. Learn about our journey, milestones, and the passion that drives us to deliver exceptional IT solutions and services." />
</Helmet>

      <motion.h4
        className="absolute top-0 left-0 text-sm font-semibold text-blue-500 mt-4 md:mt-0 ml-6 md:ml-12"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        OUR STORY
      </motion.h4>

      <div className="container mx-auto px-4 md:px-8 flex flex-col md:flex-row gap-8 relative">
        {/* Left Container */}
        <motion.div
          className="bg-white p-8 flex flex-col justify-between md:w-1/2 shadow-lg rounded-lg"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Heading */}
          <h1 className="text-2xl md:text-3xl font-bold text-black mb-6 leading-relaxed md:leading-relaxed">
            {storyData.heading}
          </h1>

          {/* Image and Text */}
          <div className="flex items-center mt-auto">
            {/* Circle Image */}
            <motion.img loading="lazy"
              src={storyData.image}
              alt="Circle"
              className="w-16 h-16 md:w-20 md:h-20 rounded-full object-cover mr-4 md:mr-6 shadow-md"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            />
            <p className="text-gray-600 text-base md:text-lg leading-relaxed">
              {storyData.description}
            </p>
          </div>
        </motion.div>

       
        <div className="flex flex-col md:w-1/2 gap-6 shadow-md rounded-lg">
          {storyData.sections.map((section, index) => (
            <motion.div
              key={index}
              className="bg-white p-6 md:p-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h3 className="text-xl md:text-2xl font-bold text-black mb-4">
                {section.number}. <span className='ml-2'>{section.title}</span>
              </h3>
              <p className="text-gray-600 text-base md:text-lg leading-relaxed ml-10">
                {section.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Story;
