import { motion } from 'framer-motion';
import { visionData } from '../../constants'; 
import { Helmet } from 'react-helmet';
const MobileVision = () => {
  return (
    <div className="py-8 px-4 bg-white">
       <Helmet>
 
  <meta name="description" content="Learn about Vectrium Ventures' vision for the future. Discover our long-term goals and how we plan to drive innovation and excellence in the IT industry." />
</Helmet>
      <div className="mb-6">
        <motion.img loading="lazy"
          src={visionData.imageSrc} 
          alt="Vision Image"
          className="w-full h-auto object-cover rounded-xl"
          whileHover={{ scale: 1.05 }} 
          initial={{ opacity: 0, scale: 0.9 }} 
          animate={{ opacity: 1, scale: 1 }} 
          transition={{ duration: 0.5 }} 
        />
      </div>

      {/* Mobile Vision Text with Animation */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <h1 className="text-3xl font-bold text-black mb-4 text-center">{visionData.title}</h1>
        <p className="text-gray-600 text-base leading-relaxed text-center">
          {visionData.description}
        </p>
      </motion.div>
    </div>
  );
};

export default MobileVision;
