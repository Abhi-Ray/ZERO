import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from "./components/Navbar";
import Header from "./components/Header";
import Brands from "./components/Brands";
import Solutions from "./components/Solutions";
import Business from "./components/Business";
import Service from "./components/Services";
import Features from "./components/Features";
import Opportunity from "./components/Opportunity";
import Contacts from './components/Contacts/Contacts';
import Career from "./components/Career/Career";
import Services from "./components/Services/Services";
import About from "./components/AboutUs/About";
import PrivacyPolicy from './components/PrivacyPolicy';
import Terms from "./components/Terms";
import Footer from './components/Footer';

function AppContent() {
  const location = useLocation();

  return (
    <div>
      
      {(location.pathname !== '/contacts' && location.pathname !== '/career' && location.pathname !== '/services' && location.pathname !== '/about' && location.pathname !== '/privacy-policy' && location.pathname !== '/terms') && (
  <div className="bg-cover bg-center bg-no-repeat mt-16"loading="lazy" style={{ backgroundImage: "url('/Images/bg-img-3-min.jpg')" }}>
   
    <Header />
    
  </div>
)}

      {/* Define Routes */}
      <Routes>
        <Route path="/" element={
          <>
           <Navbar />
            <Brands />
            <Solutions />
            <Business />
            <Service />
            <Features />
            <Opportunity />
            <Footer />
          </>
        } />
        <Route path="/contacts" element={<Contacts />} />
        <Route path="/career" element={<Career />} />
        <Route path="/services" element={<Services />} />
        <Route path="/about" element={<About />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy />} />
        <Route path="/terms" element={<Terms />} />
      </Routes>
    </div>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
