import { motion } from 'framer-motion';
import { FaLongArrowAltRight } from 'react-icons/fa';
import { Helmet } from 'react-helmet'; 

import MobileOpportunity from './MobileOpportunity';
import MediumOpportunity from './MediumOpportunity';
import { containerVariants, buttonVariants } from "../constants";

const Opportunity = () => {
  const handleCallNow = () => {
   
    window.location.href = "https://wa.link/a9nffo"; 
  };

  return (
    <div className="flex flex-col min-h-screen bg-red-100">
   
      <Helmet>
        <meta name="description" content="Explore exciting opportunities with Perfinitum Innovations. Act now to take advantage of our services and make the most out of your business potential." />
        <meta name="keywords" content="opportunity, Perfinitum Innovations, business growth, services, call to action" />
      </Helmet>

     
      <div className="hidden lg:flex flex-col items-center justify-center min-h-screen px-6 mx-4 sm:mx-14 sm:px-14 bg-cover bg-center bg-no-repeat rounded-lg relative" style={{ backgroundImage: 'url("./Images/bg-img.jpg")' }}>
        <div className="absolute inset-0 bg-red-600 opacity-40 blur-sm"></div> 
        <motion.div
          className="relative bg-white bg-opacity-20 p-8 border border-slate-200 rounded-lg flex flex-col items-center w-full sm:h-96 mb-8"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <h1 className="text-white text-xl sm:text-4xl mt-10 sm:mt-14 font-semibold text-center leading-snug tracking-wide">
            Act now, using our <br className="sm:hidden" />
            <span className="block mt-1 sm:mt-2">opportunities</span>
          </h1>
         
          <motion.button
            className="bg-white text-red-500 px-6 py-3 rounded-full flex items-center hover:bg-red-900 focus:outline-none mt-6 font-bold"
            initial="hidden"
            animate="visible"
            variants={buttonVariants}
            onClick={handleCallNow}
          >
            <span>Call Now</span>
            <FaLongArrowAltRight className="ml-2" />
          </motion.button>
        </motion.div>
      </div>

      {/* Medium View */}
      <div className="hidden lg:hidden md:flex flex-col justify-center items-center h-full">
        <MediumOpportunity />
      </div>

      {/* Mobile View */}
      <div className="block md:hidden flex-col justify-center items-center h-full">
        <MobileOpportunity />
      </div>
    </div>
  );
};

export default Opportunity;
