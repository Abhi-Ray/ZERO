import { useState } from "react";
import { FaBars, FaTimes } from "react-icons/fa";
import { Link } from "react-router-dom";
import { NAV_LINKS } from "../constants";

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 w-full bg-black shadow-md text-red-900 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo Section */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center ml-8">
              <img
                src="/Images/PIPL RED.png"
                alt="logo"
                className="w-24 md:w-28 lg:w-28 mt-2 fixed"
                style={{ flexShrink: 0 }}
                loading="lazy"
              />
              
            </Link>
          </div>

          {/* Mobile Menu Toggle Button */}
          <div className="flex md:hidden items-center">
            <button
              className="text-red-500 hover:text-gray-400"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
            </button>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center justify-center flex-grow space-x-8 mr-28 whitespace-nowrap">
            {/* Navigation Links */}
            <div className="flex space-x-4 justify-center md:ml-48">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.key}
                  to={link.href}
                  className="text-red-900 hover:bg-red-600 hover:text-white px-3 py-2 rounded-md text-md font-medium"
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Call Now Button */}
            <div className="ml-8">
              <a
                href="https://wa.link/a9nffo"
                className="text-red-900 border border-red-900 px-6 py-2 rounded-md lg:text-md md:text-sm font-medium transition-colors duration-300 hover:bg-red-600 hover:text-white transform hover:scale-105 whitespace-nowrap"
              >
                Call Now
              </a>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <div
          className={`fixed inset-0 bg-red-600 text-white flex flex-col items-center space-y-4 pt-16 transition-transform duration-300 ease-in-out ${
            isMobileMenuOpen ? "translate-x-0" : "translate-x-full"
          } z-50`}
        >
          <button
            className="absolute top-4 right-4 text-white"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <FaTimes size={24} />
          </button>
          {NAV_LINKS.map((link) => (
            <Link
              key={link.key}
              to={link.href}
              className="text-white hover:bg-red-900 px-4 py-2 rounded-md text-md font-medium"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {link.label}
            </Link>
          ))}

          <a  href="https://wa.link/a9nffo">
            <button className="text-white hover:bg-red-900 border border-white px-6 py-2 rounded-md text-md font-medium whitespace-nowrap">
              Call Now
            </button>
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
