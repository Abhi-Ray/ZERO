import { useState } from 'react';
import { motion } from 'framer-motion';
import { FaUser, FaEnvelope, FaLongArrowAltRight, FaPhone } from 'react-icons/fa';
import 'react-phone-input-2/lib/style.css';
import Navbar from '../Navbar';
import Footer from '../Footer';
import { Helmet } from 'react-helmet';

const Contacts = () => {
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', phone: '', message: ''
  });
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const maxChars = 300;

  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value.slice(0, maxChars),
    });
  };

  
  const handleSubmit = (e) => {
    e.preventDefault(); 

  
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.phone || !formData.message) {
      setErrorMessage('Please fill out all fields.');
      setSuccessMessage('');
      return;
    }

    if (!/\S+@\S+\.\S+/.test(formData.email)) {
      setErrorMessage('Please enter a valid email address.');
      setSuccessMessage('');
      return;
    }

    // Simulate sending the form
    setSuccessMessage('Thank you! Your message has been sent.');
    setErrorMessage('');
    setFormData({ firstName: '', lastName: '', email: '', phone: '', message: '' });
  };

  return (
    <div
      className="min-h-screen bg-cover bg-center" loading="lazy"
      style={{
        backgroundImage: 'url("/Images/background-img.jpg")',
      }}
    >
      <Helmet>
        <title>Contact Us | Perfinitum Innovations</title>
        <meta name="description" content="Get in touch with Perfinitum Innovations for inquiries, IT solutions, support, or consultations. Contact us through our form, email, or phone to discuss your website development, graphic design, and digital marketing needs." />
        <meta name="keywords" content="Contact Perfinitum Innovations, IT Solutions Contact, Website Development Support, Graphic Design Contact, Digital Marketing Inquiries, Perfinitum Innovations Phone, Contact Form, Business Consultation" />
      </Helmet>

      {/* Navbar */}
      <Navbar />

      <div className="flex items-center justify-center min-h-screen px-4 mt-16">
        <motion.div
          className=" p-6 rounded-xl shadow-md w-full max-w-[500px] relative"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center justify-start mb-4 flex-col sm:flex-row">
            <img 
              src="/Images/PIPL RED.png" 
              loading="lazy" 
              alt="Company Logo" 
              className="w-20 mb-4 sm:mb-0 "
            />
            
          </div>

          <div className="mb-6">
            <h1 className="text-3xl mb-2 font-bold text-center sm:text-left">Let’s Get In Touch.</h1>
            <p className="text-md text-black mb-1 text-center sm:text-left">
              Or just reach out manually to 
              <a href="mailto:perfinituminnovations@gmail.com" className="text-red-500"> perfinituminnovations@gmail.com </a>
            </p>
          </div>

          {successMessage && <p className="text-red-500 text-center">{successMessage}</p>}
          {errorMessage && <p className="text-red-500 text-center">{errorMessage}</p>}

          <form action="https://formsubmit.co/perfinituminnovations@gmail.com" method="POST">
          <input type="hidden" name="_template" value="table"/>

            <div className="flex flex-col sm:flex-row gap-4 mb-4">
              <div className="flex-1 relative">
                <motion.div
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 text-black opacity-50 mt-3"
                  
                >
                  <FaUser />
                </motion.div>
                <label htmlFor="firstName" className="block text-black font-medium">First Name</label>
                <input
                  type="text"
                  id="firstName"
                  name="firstName"
                  placeholder='Enter your first name...'
                  value={formData.firstName}
                  onChange={handleChange}
                  className="mt-1 block w-full p-2 pl-10 border border-gray-300 rounded-3xl placeholder:font-semibold transition-shadow duration-300 focus:shadow-lg"
                />
              </div>
              <div className="flex-1 relative">
                <motion.div
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 text-black opacity-50 mt-3"
                  
                >
                  <FaUser />
                </motion.div>
                <label htmlFor="lastName" className="block text-black font-medium">Last Name</label>
                <input
                  type="text"
                  id="lastName"
                  name="lastName"
                  placeholder='Enter your last name...'
                  value={formData.lastName}
                  onChange={handleChange}
                  className="mt-1 block w-full p-2 pl-10 border border-gray-300 rounded-3xl placeholder:font-semibold transition-shadow duration-300 focus:shadow-lg"
                />
              </div>
            </div>

            <div className="mb-4 relative">
              <motion.div
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-black mt-3 opacity-50"
               
              >
                <FaEnvelope />
              </motion.div>
              <label htmlFor="email" className="block text-black font-medium">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                placeholder='Enter your email address...'
                value={formData.email}
                onChange={handleChange}
                className="mt-1 block w-full p-2 pl-10 border border-gray-300 rounded-3xl placeholder:font-semibold transition-shadow duration-300 focus:shadow-lg"
              />
            </div>

            <div className="mb-4 relative">
              <motion.div
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-black opacity-50 mt-3"
               
              >
                <FaPhone />
              </motion.div>
              <label htmlFor="phone" className="block text-black font-medium">Phone</label>
              <input
                type="tel"
                id="phone"
                name="phone"
                placeholder='Enter your mobile number...'
                value={formData.phone}
                onChange={handleChange}
                className="mt-1 block w-full p-2 pl-10 border border-gray-300 rounded-3xl placeholder:font-semibold transition-shadow duration-300 focus:shadow-lg"
              />
            </div>

            <div className="mb-4">
              <label htmlFor="message" className="block text-black font-medium">Message</label>
              <textarea
                id="message"
                name="message"
                placeholder='Your message here...'
                value={formData.message}
                onChange={handleChange}
                className="mt-1 block w-full p-2 border border-gray-300 rounded-3xl placeholder:font-semibold transition-shadow duration-300 focus:shadow-lg"
                rows="4"
              />
            </div>

            <motion.button
              type="submit"
              className="w-full flex items-center justify-center bg-red-600 text-white p-2 rounded-3xl space-x-2 mt-8"
              whileHover={{ scale: 1.05, backgroundColor: "#f63e3b" }}
              transition={{ duration: 0.3 }}
            >
              <span>Submit Form</span>
              <FaLongArrowAltRight />

            </motion.button>
          </form>
        </motion.div>
      </div>

      <Footer />
    </div>
  );
};

export default Contacts;
