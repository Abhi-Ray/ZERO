import { motion } from 'framer-motion';
import { storyData } from '../../constants/Aboutus/Story'; 
import { Helmet } from 'react-helmet';
const MobileStory = () => {
  return (
    <div className="py-8">
        <Helmet>
 
  <meta name="description" content="Explore the story behind Perfinitum Innovations. Learn about our journey, milestones, and the passion that drives us to deliver exceptional IT solutions and services." />
</Helmet>
      {/* Mobile View Heading */}
      <motion.h4
        className="text-center text-sm font-semibold text-red-500 mb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        OUR STORY
      </motion.h4>

      <div className="flex flex-col gap-8 px-4">
        {/* Top Section */}
        <motion.div
          className="bg-white p-6 rounded-lg shadow-md"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-xl font-bold text-black mb-4">
            {storyData.heading}
          </h1>

          {/* Image and Description */}
          <div className="flex flex-col sm:flex-row items-center mt-4">
            <motion.img loading="lazy"
              src={storyData.image} 
              alt="Circle"
              className="w-20 h-20 rounded-full object-cover mb-4 sm:mb-0 sm:mr-6"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            />
            <p className="text-gray-600 text-base leading-[1.75]">
              {storyData.description}
            </p>
          </div>
        </motion.div>

        {/* Three Sections */}
        <div className="flex flex-col gap-4 rounded-xl shadow-md">
          {storyData.sections.map((section, index) => (
            <motion.div
              key={index}
              className="bg-white p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h3 className="text-xl font-bold text-black mb-2">
                {section.number}. <span className='ml-2'>{section.title}</span>
              </h3>
              <p className="text-gray-600 text-base leading-[1.75] ml-10">
                {section.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MobileStory;
