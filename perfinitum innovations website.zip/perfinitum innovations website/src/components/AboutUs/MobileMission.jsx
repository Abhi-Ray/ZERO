import { motion } from 'framer-motion';
import { missionStats } from '../../constants'; 
import { Helmet } from 'react-helmet';
const MobileMission = () => {
  return (
    <div className="py-8 px-4">
      <Helmet>
  
  <meta name="description" content="Discover Perfinitum Innovations' mission to provide innovative IT solutions, drive technological advancements, and deliver unparalleled value to our clients through dedication and expertise." />
</Helmet>

      {/* Mobile Header Section */}
      <motion.h1
        className="text-3xl font-bold text-black text-center mb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {missionStats.header}
      </motion.h1>

      <motion.p
        className="text-gray-600 text-base leading-relaxed text-center mb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        {missionStats.description}
      </motion.p>

      {/* Mobile Image with Hover Effect */}
      <div className="mb-6">
        <motion.img loading="lazy"
          src={missionStats.imageSrc}
          alt="Mission Image"
          className="w-full h-auto object-cover rounded-xl"
          whileHover={{ scale: 1.05 }}
          transition={{ type: 'spring', stiffness: 300, duration: 0.5 }}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        />
      </div>

      {/* Mobile Statistics */}
      <motion.div
        className="flex flex-row justify-between items-center gap-8 text-center py-2 bg-red-100 rounded-lg"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        {missionStats.stats.map((stat, index) => (
          <motion.div
            key={index}
            className="flex flex-col items-center mt-4"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 + 0.1 * index }}
          >
            <h2 className="text-3xl font-bold text-black mb-2">{stat.value}</h2>
            <p className="text-gray-600 text-sm">{stat.label}</p>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
};

export default MobileMission;
