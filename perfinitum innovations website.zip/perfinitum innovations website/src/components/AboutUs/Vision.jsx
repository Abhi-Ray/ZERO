import { motion } from 'framer-motion';
import { visionData } from '../../constants'; 
import { Helmet } from 'react-helmet';
const Vision = () => {
  return (
    <div className="py-8 mt-16">
      <Helmet>
  
  <meta name="description" content="Learn about Perfinitum Innovations' vision for the future. Discover our long-term goals and how we plan to drive innovation and excellence in the IT industry." />
</Helmet>

      <div className="container mx-auto px-4 flex flex-col md:flex-row gap-8">
        {/* Left Container */}
        <div className="md:w-1/2 flex items-center justify-center bg-white p-8">
          <motion.img loading="lazy"
            src={visionData.imageSrc} 
            alt="Vision Image"
            className="w-full h-auto object-cover rounded-xl"
            whileHover={{ scale: 1.05 }} 
            transition={{ type: 'spring', stiffness: 300, duration: 0.5 }}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
          />
        </div>

        {/* Right Container */}
        <div className="md:w-1/2 flex flex-col justify-center bg-white p-8">
          <motion.h1
            className="text-5xl font-bold text-black mb-8"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            {visionData.title}
          </motion.h1>
          <motion.p
            className="text-gray-600 text-lg leading-[2.0] mb-8"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {visionData.description}
          </motion.p>
        </div>
      </div>
    </div>
  );
};

export default Vision;
