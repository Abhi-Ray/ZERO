import { motion } from 'framer-motion';
import Navbar from '../Navbar';
import Mission from './Mission';
import Story from './Story';
import Vision from './Vision';
import Footer from '../Footer';
import MobileAbout from './MobileAbout';
import MobileStory from './MobileStory';
import MobileMission from './MobileMission';
import MobileVision from './MobileVision';
import { Helmet } from 'react-helmet';

const About = () => {
  return (
    <div className="flex flex-col min-h-screen">
     <Helmet>
  <title>About Us | Perfinitum Innovations</title>
  <meta name="description" content="Learn more about Perfinitum Innovations, a leading IT solution service provider in Indore, specializing in website development, graphic designing, UI/UX design, brand building, and digital marketing. Explore our values, team, and commitment to excellence." />
  <meta name="keywords" content="Perfinitum Innovations, About Perfinitum Innovations, IT Solutions Indore, Website Development, Graphic Designing, UI/UX Design, Digital Marketing, Brand Building, Business Consultation, Indore" />
</Helmet>


      {/* Navbar Section */}
      <Navbar />

      <motion.div
        className="hidden md:block min-h-screen bg-cover bg-center bg-no-repeat mt-16"
        style={{ backgroundImage: "url('/Images/bg-img-1.jpg')" }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <motion.div
          className="flex flex-col justify-center items-center h-full mt-16"
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-5xl font-bold text-black mb-12 mt-28 text-center">
            We’re changing the
            <br className="hidden sm:inline" />
            <span className="block sm:inline mt-2">whole game.</span>
          </h1>

          {/* Buttons */}
          <div className="flex">
            <a href="https://wa.link/a9nffo" className="flex">
              <motion.button
                className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-8 rounded-3xl"
                whileHover={{ scale: 1.05 }}
                transition={{ type: 'spring', stiffness: 300 }}
              >
                Call Now
              </motion.button>
            </a>
          </div>
        </motion.div>
      </motion.div>

      {/* Desktop View Components */}
      <motion.div
        className="flex-grow hidden md:block"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Story />
        <Mission />
        <Vision />
      </motion.div>

      {/* Mobile View Components */}
      <motion.div
        className="block md:hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <MobileAbout />
        <MobileStory />
        <MobileMission />
        <MobileVision />
      </motion.div>

      {/* Desktop Footer */}
      <motion.div
        className="lg:block text-white p-4 justify-around rounded-lg"
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Footer />
      </motion.div>
    </div>
  );
}

export default About;
