import { useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { FaLongArrowAltRight, FaLongArrowAltLeft } from 'react-icons/fa';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { services } from '../constants/Services';


const Services = () => {
  const carouselRef = useRef(null);  
  const nextButtonRef = useRef(null); 

  useEffect(() => {
    const interval = setInterval(() => {
      if (nextButtonRef.current) {
        nextButtonRef.current.click(); 
      }
    }, 3000);  

    return () => clearInterval(interval); 
  }, []);

  return (
    <>
      <Helmet>
        <meta name="description" content="Explore the range of services offered by Perfinitum Innovations, including website development, graphic designing, UI/UX web designing, brand building, social media handling, business consultation, SEO, and digital marketing." />
        <meta name="keywords" content="website development, graphic designing, UI/UX web designing, brand building, social media handling, business consultation, SEO, digital marketing" />
      </Helmet>

      <div className="w-full min-h-screen bg-white py-20 flex flex-col items-center mt-28">
        <motion.h1
          className="text-4xl font-bold text-center mb-12  md:block"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          Services Offered by Us
        </motion.h1>

        <div className="w-full px-8 lg:px-20">
          {/* Desktop View */}
          <div className=" md:block">
            <Carousel
              ref={carouselRef}  
              opts={{
                align: 'start',
                itemsToShow: 3,
                slidesToScroll: 1,
                infinite: true, 
                loop: true 
              }}
              className="w-full max-w-full mx-auto relative"
            >
              <CarouselContent className="flex gap-2">
                {services.map((service, index) => (
                  <CarouselItem key={index} className="flex-none w-full max-w-xs">
                    <motion.div
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5 }}
                    >
                      <Card className="w-full min-h-[380px] shadow-lg transition-transform transform hover:scale-95">
                        <CardContent className="relative flex flex-col items-center p-4 space-y-4">
                          
                          <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center shadow-lg border border-red-500">
                            
                            <service.icon className="w-10 h-10 text-red-600" />
                          </div>
                          <div className="text-center">
                            <h1 className="text-xl font-bold text-gray-800">{service.title}</h1>
                            <p className="text-base mt-4 text-gray-600">
                              {service.description}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="hidden">
                <FaLongArrowAltLeft />
              </CarouselPrevious>
              <CarouselNext
                ref={nextButtonRef} 
                className="hidden"
              >
                <FaLongArrowAltRight />
              </CarouselNext>
            </Carousel>
          </div>
        
        </div>
      </div>
    </>
  );
};

export default Services;
