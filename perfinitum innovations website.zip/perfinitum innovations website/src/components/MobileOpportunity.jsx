import { Helmet } from 'react-helmet';
import { FaLongArrowAltRight } from 'react-icons/fa'; 
import { motion } from 'framer-motion';
import { containerVariants, buttonVariants } from "../constants";

const MobileOpportunity = () => {
  const handleCallNow = () => {
    window.location.href = "https://wa.link/a9nffo"; 
  };

  return (
    <div
      className="flex flex-col min-h-screen justify-center items-center bg-cover bg-center"
      style={{ backgroundImage: 'url("./Images/bg-img.jpg")' }} 
    >
      <Helmet>
        <meta name="description" content="Explore exciting opportunities with Perfinitum Innovations. Act now to take advantage of our services and make the most out of your business potential." />
      </Helmet>

      <motion.div
        className="flex flex-col items-center justify-center w-full max-w-sm py-6 sm:py-8 sm:px-6"
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <motion.div
          className="bg-white bg-opacity-30 p-6 border border-slate-200 rounded-lg flex flex-col items-center w-full shadow-xl"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <h1 className="text-white text-lg sm:text-xl mt-4 sm:mt-6 font-semibold text-center leading-snug tracking-wide">
            Act now, using our <br className="hidden sm:block" /> 
            <span className="block mt-1">opportunities</span>
          </h1>

          {/* Call Now Button */}
          <motion.button
            className="bg-white text-red-600 px-8 py-3 rounded-full flex items-center hover:bg-red-800 hover:text-white transition-colors duration-300 focus:outline-none mt-6 font-bold shadow-md"
            initial="hidden"
            animate="visible"
            variants={buttonVariants}
            onClick={handleCallNow}
          >
            <span>Call Now</span>
            <FaLongArrowAltRight className="ml-2" />
          </motion.button>
        </motion.div>
      </motion.div>

      
      <div className="flex justify-center items-center mt-12 mb-8">
        <img
          src="./Images/callnow.jpg" 
          alt="Opportunity"
          className="w-full h-64 max-w-xs object-cover rounded-lg shadow-md"
        />
      </div>
    </div>
  );
};

export default MobileOpportunity;
