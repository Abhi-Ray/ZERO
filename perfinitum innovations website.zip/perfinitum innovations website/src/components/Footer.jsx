import { FaLinkedin, FaWhatsapp, FaFacebookF, FaInstagram, FaTwitter } from 'react-icons/fa';
import { footerContent } from '../constants/Footer';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const iconComponents = {
  FaLinkedin,
  FaWhatsapp,
  FaFacebookF,
  FaInstagram,
  FaTwitter,
};

const Footer = () => {
  return (
    <motion.div
      className="bg-[#100907fe] text-white py-12 px-4 md:px-6 lg:px-12 w-full rounded-lg animate-fadeIn"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Helmet>
        <meta name="description" content="Discover our comprehensive footer section for Perfinitum Innovations, providing quick links, contact information, and helpful resources to navigate through our services." />
      </Helmet>

      <div className="container mx-auto flex flex-col items-center">
        {/* Left Side */}
        <motion.div
          className="flex flex-col items-center text-center"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <img
            loading="lazy"
            src={footerContent.logo.src}
            alt={footerContent.logo.alt}
            className="h-16 w-20 mb-6"
          />
          <div className="flex flex-col items-center">
            <h2 className="text-xl font-semibold mb-2">{footerContent.logo.companyName}</h2>
            <p className="text-sm text-gray-400 mb-2">
              Address: {footerContent.logo.address} <br />
              Email: {footerContent.logo.email} <br/>
              PhoneNumber: {footerContent.logo.phone}
            </p>
            <div className="flex space-x-3 mt-2">
              {footerContent.logo.socialLinks.map((link, index) => {
                const IconComponent = iconComponents[link.icon];
                return (
                  <motion.a
                    key={index}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.1 }}
                    transition={{ type: 'spring', stiffness: 300 }}
                  >
                    <IconComponent className="text-xl hover:text-red-600 transition-transform transform-gpu" />
                  </motion.a>
                );
              })}
            </div>
          </div>
        </motion.div>

        {/* Footer Bottom */}
        <motion.div
          className="border-t border-gray-600 mt-6 pt-4 w-full"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <div className="flex flex-col items-center md:flex-row md:justify-between md:items-center">
            {/* Bottom Links Section */}
            <motion.div
              className="flex items-center justify-center md:justify-start space-y-2 md:space-y-0"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              <p className="text-gray-400 text-xs md:text-sm">{footerContent.bottomLinks.rights}</p>
            </motion.div>
            {/* Policy Links Section */}
            <motion.div
              className="flex flex-row items-center justify-center md:justify-end space-x-4 mt-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.8 }}
            >
              {/* {footerContent.bottomLinks.policyLinks.map((policyLink, index) => (
                <a
                  key={index}
                  href={policyLink.href}
                  className="text-gray-400 text-xs md:text-sm hover:text-white"
                >
                  {policyLink.text}
                </a>
              ))} */}
            </motion.div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Footer;
