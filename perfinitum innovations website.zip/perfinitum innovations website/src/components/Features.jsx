import { useState } from 'react';
import { FaChevronDown, FaDesktop, FaMobileAlt, FaTools } from 'react-icons/fa';
import { motion, AnimatePresence } from 'framer-motion';
import DropdownContent from './DropdownContent';
import {containerVariants,itemVariants} from "../constants";
import { Helmet } from 'react-helmet';


const Features = () => {
  const [activeIndex, setActiveIndex] = useState(null);
  return (
    <div className="w-full -mt-32  px-4 lg:px-10 bg-gray-100 flex flex-col items-center  ">
      <Helmet>
  
  <meta name="description" content="Explore the unique features offered by Perfinitum Innovations, designed to help businesses grow and succeed through innovative IT solutions and services." />
</Helmet>

      {/* Heading */}
      <motion.div
        className="w-full flex flex-col items-start mb-10 max-w-screen-lg "
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <div className="relative mb-4">
          {/* Heading Line */}
          <div className="absolute top-0 left-0 w-1 h-12 bg-red-600 mt-8"></div>
          <h2 className="relative text-2xl lg:text-3xl font-bold pl-6 mt-8">Our Features</h2>
        </div>
      </motion.div>

      {/* Main Content with 2 Columns */}
      <div className="flex flex-col lg:flex-row w-full items-start lg:items-stretch max-w-screen-lg">
        {/* Left Column: Feature Containers */}
        <div className="flex-1 flex flex-col gap-4 w-full lg:w-1/2 lg:mr-12">
          {/* Container 1 */}
          <motion.div
            className="flex flex-col lg:flex-row items-center bg-white border border-gray-300 rounded-lg shadow-md p-4 w-full"
            initial="hidden"
            animate="visible"
            variants={containerVariants}
          >
            <div className="flex-shrink-0 mb-4 lg:mb-0">
              <div className="flex items-center justify-center bg-gray-100 border border-slate-100 w-14 h-14 rounded-lg">
                <FaDesktop className="text-2xl lg:text-3xl text-red-600" />
              </div>
            </div>
            <div className="flex-1 flex flex-col justify-center px-4 text-center lg:text-left">
              <h3 className="text-lg lg:text-xl font-semibold mb-2">Brand Building</h3>
            </div>
            <div>
              <button
                onClick={() => setActiveIndex(activeIndex === 1 ? null : 1)}
                className="flex items-center text-red-600 hover:text-red-800"
              >
                <FaChevronDown
                  className={`ml-2 transition-transform ${activeIndex === 1 ? 'rotate-180' : ''}`}
                />
              </button>
            </div>
          </motion.div>
          <AnimatePresence>
            {activeIndex === 1 && (
              <motion.div
                className="animate-slideDown"
                initial="hidden"
                animate="visible"
                exit="hidden"
                variants={itemVariants}
              >
                <DropdownContent className="animate-slideDown" activeIndex={1} />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Container 2 */}
          <motion.div
            className="flex flex-col lg:flex-row items-center bg-white border border-gray-300 rounded-lg shadow-md p-4 w-full"
            initial="hidden"
            animate="visible"
            variants={containerVariants}
          >
            <div className="flex-shrink-0 mb-4 lg:mb-0">
              <div className="flex items-center justify-center bg-gray-100 border border-slate-100 w-14 h-14 rounded-lg">
                <FaMobileAlt className="text-2xl lg:text-3xl text-red-600" />
              </div>
            </div>
            <div className="flex-1 flex flex-col justify-center px-4 text-center lg:text-left">
              <h3 className="text-lg lg:text-xl font-semibold mb-2">Social Media Handling</h3>
            </div>
            <div>
              <button
                onClick={() => setActiveIndex(activeIndex === 2 ? null : 2)}
                className="flex items-center text-red-600 hover:text-red-800"
              >
                <FaChevronDown
                  className={`ml-2 transition-transform ${activeIndex === 2 ? 'rotate-180' : ''}`}
                />
              </button>
            </div>
          </motion.div>
          <AnimatePresence>
            {activeIndex === 2 && (
              <motion.div
                className="animate-slideDown"
                initial="hidden"
                animate="visible"
                exit="hidden"
                variants={itemVariants}
              >
                <DropdownContent className="animate-slideDown" activeIndex={2} />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Container 3 */}
          <motion.div
            className="flex flex-col lg:flex-row items-center bg-white border border-gray-300 rounded-lg shadow-md p-4 w-full"
            initial="hidden"
            animate="visible"
            variants={containerVariants}
          >
            <div className="flex-shrink-0 mb-4 lg:mb-0">
              <div className="flex items-center justify-center bg-gray-100 border border-slate-100 w-14 h-14 rounded-lg">
                <FaTools className="text-2xl lg:text-3xl text-red-600" />
              </div>
            </div>
            <div className="flex-1 flex flex-col justify-center px-4 text-center lg:text-left">
              <h3 className="text-lg lg:text-xl font-semibold mb-2">Business Consultation</h3>
            </div>
            <div>
              <button
                onClick={() => setActiveIndex(activeIndex === 3 ? null : 3)}
                className="flex items-center text-red-600 hover:text-red-800"
              >
                <FaChevronDown
                  className={`ml-2 transition-transform ${activeIndex === 3 ? 'rotate-180' : ''}`}
                />
              </button>
            </div>
          </motion.div>
          <AnimatePresence>
            {activeIndex === 3 && (
              <motion.div
                className="animate-slideDown"
                initial="hidden"
                animate="visible"
                exit="hidden"
                variants={itemVariants}
              >
                <DropdownContent className="animate-slideDown" activeIndex={3} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Column: Image */}
        <motion.div
          className="flex-1 w-full lg:w-1/2 flex justify-center mb-10 mt-10  lg:mt-0 "
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <img loading="lazy"
            src="/Images/feature.jpg"
            alt="Feature Image"
            className="rounded-xl shadow-lg object-cover w-full max-w-[500px] lg:max-w-[600px] transition-transform transform hover:scale-105"
          />
        </motion.div>
      </div>
    </div>
  );
};

export default Features;
