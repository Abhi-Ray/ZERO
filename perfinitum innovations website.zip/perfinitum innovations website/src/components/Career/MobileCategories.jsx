import { motion } from 'framer-motion';
import { Job } from '../../constants/career/categories'; 
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';


const MobileCategories = () => {
  return (
    <div className="flex justify-center items-center min-h-screen">
      <Helmet>
  
  <meta name="description" content="Explore our category page to find detailed information on various services and solutions offered by Perfinitum Innovations. Discover how we can help you with your business needs." />
</Helmet>

      <div className="w-full max-w-4xl p-6">
        <h2 className="text-3xl font-bold text-black mb-8 text-center">
          Most Demanded <br className="hidden sm:inline mb-4" />
          Job Categories
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {Job.map((category, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: category.delay }} 
              whileHover={{ scale: 1.05, boxShadow: "0 6px 12px rgba(0,0,0,0.2)" }}
            >
              <Link 
                to={category.href} 
                className="bg-white shadow-md rounded-lg flex flex-col items-center p-6 hover:bg-red-50 hover:text-red-700 transition-colors duration-300"
              >
                <div className="flex flex-col items-center text-center">
                  <category.icon className="text-red-600 text-4xl mb-3" /> 
                  <span className="text-lg font-semibold">{category.name}</span>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MobileCategories;
