import { useState } from 'react';
import { Link } from 'react-router-dom';
import MobileCategories from './MobileCategories';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Job } from "../../constants/career/categories"; 

export const Category = () => {
  const [activeCategory, setActiveCategory] = useState(null);

  const handleCategoryClick = (category) => {
    setActiveCategory(category);
  };

  return (
    <div className="p-8 mx-auto max-w-7xl">
     <Helmet>
  
  <meta name="description" content="Explore our category page to find detailed information on various services and solutions offered by Perfinitum Innovations. Discover how we can help you with your business needs." />
</Helmet>
      <h2 className="text-3xl font-bold text-black mb-8 lg:mb-12 hidden  md:hidden lg:block">
        Most Demanded Job Categories
      </h2>
      
      {/* Desktop View */}
      <div className="hidden lg:flex space-x-4">
        {Job.map((category) => {
          const Icon = category.icon; 

          return (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: category.delay }}
              whileHover={{ scale: 1.05, boxShadow: "0 10px 20px rgba(0,0,0,0.2)" }}
            >
              <Link 
                to={category.href} 
                onClick={() => handleCategoryClick(category.name)} 
                className={`relative w-56 h-56 shadow-lg rounded-lg flex items-center justify-center flex-col p-4 transition-colors duration-300 ${activeCategory === category.name ? 'bg-red-200' : 'bg-white'} hover:bg-red-100`}
              >
                <Icon className="text-red-600 text-5xl" /> 
                <div className="absolute bottom-4 left-4 text-center">
                  <h2 className={`font-bold text-2xl mb-3 ${activeCategory === category.name ? 'text-red-600' : 'text-black'}`}>
                    {category.name}
                  </h2>
                </div>
              </Link>
            </motion.div>
          );
        })}
      </div>

      {/* Medium Devices View */}
     

      {/* Mobile View */}
      <div className="block lg:hidden">
        <MobileCategories />
      </div>
    </div>
  );
};

export default Category;
