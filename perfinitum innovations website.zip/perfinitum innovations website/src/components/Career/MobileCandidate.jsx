import { motion } from 'framer-motion';
import { boxData } from "../../constants/career/Candidate";
import { Helmet } from 'react-helmet';
const MobileCandidate = () => {
  return (
    <div className="flex flex-col lg:flex-row p-6 lg:p-8">
      <Helmet>
  
  <meta name="description" content="View and manage your candidate profile with Perfinitum Innovations. Update your information and track your application status as you explore career opportunities with us." />
</Helmet>

      <div className="w-full lg:w-1/2 flex justify-center lg:justify-start mb-6 lg:mb-0">
        <motion.img loading="lazy"
          src="/Images/career-min.jpg" 
          alt="Candidate Image"
          className="rounded-lg shadow-lg w-full sm:w-3/4 lg:w-3/4 object-cover"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          whileHover={{ scale: 1.05, boxShadow: "0 8px 16px rgba(0,0,0,0.2)" }}
        />
      </div>

      <div className="w-full lg:w-1/2 lg:pl-8">
        <h2 className="text-2xl sm:text-3xl font-bold mb-4 lg:mb-6">
          Perfect for Candidates.<br className="hidden sm:inline" />
          Beautiful for Employers.
        </h2>

        {/* Boxes container */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
          {boxData.map((box, index) => (
            <motion.div
              key={index}
              className="bg-white shadow-md rounded-lg p-4 flex items-start hover:bg-red-50 transition duration-300"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ scale: 1.05, boxShadow: "0 8px 16px rgba(0,0,0,0.2)" }}
            >
              <box.icon className="text-red-600 text-2xl mr-4" />
              <div>
                <h3 className="font-bold text-xl">{box.title}</h3>
                <p className="text-gray-600 text-sm sm:text-base">{box.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MobileCandidate;
