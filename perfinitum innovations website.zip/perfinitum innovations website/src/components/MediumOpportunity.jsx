import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { FaLongArrowAltRight } from 'react-icons/fa';
import { containerVariants, buttonVariants } from "../constants";

const MediumOpportunity = () => {
  const handleCallNow = () => {
    window.location.href = "https://wa.link/a9nffo"; 
  };

  return (
    <div
      className="flex flex-col min-h-screen  py-10 px-4 justify-center items-center w-full bg-cover bg-center"
      style={{ backgroundImage: 'url("./Images/bg-img.jpg")' }} 
    >
      <Helmet>
        <meta name="description" content="Explore exciting opportunities with Perfinitum Innovations. Act now to take advantage of our services and make the most out of your business potential." />
      </Helmet>

      <div className="flex flex-col items-center justify-center w-full max-w-4xl py-12 px-8 sm:px-12 md:px-16 lg:px-20">
        <motion.div
          className="bg-white bg-opacity-20 p-8 border border-slate-200 rounded-lg flex flex-col items-center w-full max-w-3xl shadow-lg"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <h1 className="text-white text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-semibold text-center leading-snug tracking-wide">
            Act now, using our <br className="hidden sm:block" />
            <span className="block mt-1">opportunities</span>
          </h1>

          {/* Call Now Button */}
          <motion.button
            className="mt-8 bg-white text-red-600 px-8 py-4 rounded-full flex items-center hover:bg-red-800 hover:text-white transition-colors duration-300 focus:outline-none font-bold shadow-lg"
            initial="hidden"
            animate="visible"
            variants={buttonVariants}
            onClick={handleCallNow}
          >
            <span>Call Now</span>
            <FaLongArrowAltRight className="ml-2" />
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
};

export default MediumOpportunity;
