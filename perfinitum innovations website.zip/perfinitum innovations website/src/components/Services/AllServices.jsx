import { motion } from "framer-motion";
import {
  FaDesktop, FaPalette, FaCode, FaBullhorn,
  FaShareSquare, FaComments, FaEdit, FaChartLine
} from 'react-icons/fa';
import { service } from "../../constants/services/AllServices" ;
import { Helmet } from 'react-helmet';
const icons = {
  FaDesktop: FaDesktop,
  FaPalette: FaPalette,
  FaCode: FaCode,
  FaBullhorn: FaBullhorn,
  FaShareSquare: FaShareSquare,
  FaComments: FaComments,
  FaEdit: FaEdit,
  FaChartLine: FaChartLine,
};

const AllServices = () => {
  return (
    <div>
      <Helmet>
  <title>Our Services |Perfinitum Innovations </title>
  <meta name="description" content="Discover the range of services offered by Perfinitum Innovations, including website development, graphic designing, UI/UX web designing, and more. Learn how we can help grow your business." />
</Helmet>

    <motion.div
      className="min-h-screen flex items-center justify-center bg-white py-8 px-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="max-w-6xl w-full text-center bg-white">
        
        <h2 className="text-lg font-semibold text-gray-800 mb-2">All Services</h2>
        <h1 className="text-4xl font-bold text-red-800 mb-6">See Our All Services</h1>
        <p className="text-lg text-gray-700 mb-8">
          Discover the range of services we offer to elevate your business. <br className="hidden sm:inline" />
          Our expert team delivers top-notch solutions to meet your unique needs.
        </p>

        {/* Map through the services array to create service boxes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 justify-items-center items-center">
          {service.map((service, index) => {
            const IconComponent = icons[service.icon];
            return (
              <motion.a
                href={service.href}
                key={index}
                className="flex flex-col items-center bg-gray-100 p-6 rounded-lg shadow-md transition-transform duration-300 hover:scale-105 hover:shadow-lg hover:bg-red-50"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <IconComponent className="text-red-600 text-4xl mb-4 transition-transform duration-300 transform hover:scale-110" />
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-gray-600 text-center">
                  {service.description}
                </p>
              </motion.a>
            );
          })}
        </div>
      </div>
    </motion.div>
    </div>
  );
};

export default AllServices;
