import { motion } from "framer-motion";
import { brandImage } from "../../constants";
import { Helmet } from 'react-helmet';

const Brands = () => {
  return (
    <div className="py-8 hidden md:block">
        <Helmet>
  
  <meta name="description" content="Explore the reputable brands we work with at Perfinitum Innovations, showcasing our partnerships and the quality of our IT and digital solutions." />
</Helmet>
      <div className="max-w-6xl mx-auto">
        <motion.div
          className="flex justify-between items-center space-x-6 overflow-x-auto"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
        >
          {brandImage.map((brand, index) => (
            <motion.img loading="lazy"
              key={index}
              src={brand}
              alt={`Brand ${index + 1}`}
              className="h-16 w-auto object-contain"
              whileHover={{ scale: 1.1 }}
              transition={{ duration: 0.3 }}
            />
          ))}
        </motion.div>
      </div>
    </div>
  );
};

export default Brands;
