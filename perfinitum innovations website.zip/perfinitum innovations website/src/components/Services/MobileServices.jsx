import { motion } from "framer-motion";
import Navbar from "../Navbar";
import { Helmet } from 'react-helmet';

const MobileServices = () => {
  return (
    <div className="min-h-screen bg-white">
       <Helmet>
  <title>Our Services | Perfinitum Innovations</title>
  <meta name="description" content="Explore the wide range of services offered by Perfinitum Innovations, including website development, graphic design, SEO, digital marketing, and business consultation." />
</Helmet>
      {/* Mobile Background Section */}
      <Navbar />
      <div
        className="min-h-screen bg-cover bg-center bg-no-repeat" loading="lazy"
        style={{ backgroundImage: "url('/Images/bg-img-1.jpg')" }}
      >
      
        <div className="p-4 text-left mt-16">
          
          <motion.h2
            className="text-md font-semibold text-black mb-8 mt-16"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Our Services
          </motion.h2>

          {/* Big Heading */}
          <motion.h1
            className="text-3xl font-bold text-red-800 mb-8 leading-tight tracking-wide"
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            We provide the <br />
            best business <br />
            solutions
          </motion.h1>

          {/* Paragraph */}
          <motion.p
            className="text-md text-black mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            We provide a range of services to help your business grow, from innovative design solutions to strategic marketing. Our team delivers high-quality results tailored to your needs.
          </motion.p>

          {/* Buttons */}
          <div className="flex flex-col space-y-4">

            <motion.a
              href="https://wa.link/a9nffo"
              className="flex items-center justify-center px-6 py-3 bg-red-600 text-white font-semibold rounded-lg shadow-md transition-transform duration-300 transform hover:scale-105 hover:bg-red-700"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              Call Now
            </motion.a>
            
          </div>
        </div>
      </div>
    </div>
  );
};

export default MobileServices;
