import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { FaUserCircle, FaStar } from "react-icons/fa";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { testimonials } from "../../constants/services/Testimonial";
import { Helmet } from 'react-helmet';

const Testimonial = () => {
  const carouselRef = useRef(null);  
  const nextButtonRef = useRef(null); 

  useEffect(() => {
    const interval = setInterval(() => {
      if (nextButtonRef.current) {
        nextButtonRef.current.click(); 
      }
    }, 2000);  

    return () => clearInterval(interval); 
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 py-16 flex flex-col items-center">
      <Helmet>
        <meta
          name="description"
          content="Discover how Perfinitum Innovations has helped businesses grow. Read testimonials from our satisfied clients about our services in website development, digital marketing, and more."
        />
      </Helmet>

      {/* Headings */}
      <div className="w-full px-4 mb-8 text-center lg:text-left lg:px-32">
        <motion.h4
          className="text-sm font-semibold text-red-600"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          TESTIMONIAL
        </motion.h4>
        <motion.h2
          className="text-3xl sm:text-4xl font-bold text-gray-800 mt-2"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          What our customers are <br className="hidden sm:inline" />
          saying about us
        </motion.h2>
      </div>

      
      <div className="w-full max-w-6xl relative px-4">
        <Carousel
        opts={{
          align: 'start',
          itemsToShow: 3,
          slidesToScroll: 1,
          infinite: true, 
          loop: true 
        }}
         ref={carouselRef} className="w-full">
          <CarouselContent>
            {testimonials.map((testimonial, index) => (
              <CarouselItem
                key={index}
                className="md:basis-1/2 lg:basis-1/3 p-4 flex justify-center"
              >
                <motion.div
                  className="w-full max-w-md"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="bg-white shadow-lg rounded-lg transition-transform duration-300 hover:scale-105 hover:shadow-2xl">
                    <CardContent className="p-6 flex flex-col justify-between">
                      <div>
                        <motion.h3
                          className="text-lg font-semibold text-gray-800 mb-2"
                          initial={{ opacity: 0, y: -20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5 }}
                        >
                          {testimonial.heading}
                        </motion.h3>
                        <motion.p
                          className="text-gray-600 mb-4"
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5 }}
                        >
                          {testimonial.quote}
                        </motion.p>
                      </div>
                      <div className="flex items-center mt-4">
                      
                        <div className="flex flex-grow items-center">
                          <div className="flex-1 flex items-center">
                            <FaUserCircle className="text-red-600 text-2xl mr-4 transition-transform duration-300 transform hover:scale-110" />
                            <div>
                              <h4 className="text-red-800 font-semibold">{testimonial.name}</h4>
                              <p className="text-gray-500 text-sm">{testimonial.title}</p>
                            </div>
                          </div>
                          <div className="border-l-2 border-gray-300 h-12 mx-4"></div> {/* Vertical line */}
                          <div className="flex items-center">
                            <span className="text-red-800 text-2xl font-bold mr-1">{testimonial.rating}</span>
                            <FaStar className="text-yellow-500 text-lg transition-transform duration-300 transform hover:scale-110" />
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <div>
            <CarouselPrevious className="hidden" />
          </div>
          <div>
            <CarouselNext ref={nextButtonRef} className="hidden" />
          </div>
        </Carousel>
      </div>
    </div>
  );
};

export default Testimonial;
