import { motion } from "framer-motion";
import { reviewData, containerVariants } from '../../constants'; 
import { Helmet } from 'react-helmet';
const Review = () => {
  return (
    <div>
        <Helmet>
 
  <meta name="description" content="Read what our satisfied clients have to say about their experiences with Perfinitum Innovations' top-notch services in IT solutions, digital marketing, and more." />
</Helmet>
    <motion.div
      className="py-12 bg-gray-50"
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:grid-cols-3">
          {reviewData.map((item, index) => (
            <motion.div
              key={index}
              className="flex flex-col items-center p-6 bg-white rounded-lg shadow-md text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
              whileHover={{ scale: 1.05 }}
            >
              <h1 className="text-2xl font-bold text-red-800">{item.value}</h1>
              <p className="text-gray-600 mt-2 text-sm">{item.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
    </div>
  );
};

export default Review;
