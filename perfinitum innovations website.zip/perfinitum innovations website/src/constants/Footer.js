

export const footerContent = {
  logo: {
    src: "/Images/PIPL RED.png",
    alt: "Company Logo",
    companyName: "Perfinitum Innovations",
    address: "Indore",
    email: "perfinituminnovations@gmail.com",
    phone: "+919669860288",
    socialLinks: [
     
      { href: "https://www.linkedin.com/company/perfinitum-innovations/?viewAsMember=true", icon: 'FaLinkedin', name: "LinkedIn" },
      { href: "https://wa.link/y841ch", icon: 'FaWhatsapp', name: "WhatsApp" },
      { href: "https://www.facebook.com/perfinitumPvtLtd?mibextid=LQQJ4d", icon: 'FaFacebookF', name: "Facebook" },
      { href: "https://www.instagram.com/perfinituminnovations?igsh=czYwYmh2M2M2dGR6", icon: 'FaInstagram', name: "Instagram" },
      // { href: "https://twitter.com", icon: 'FaTwitter', name: "Twitter" },
    ],
  },
  
  bottomLinks: {
    rights: "Copyright © 2025 | Perfinitum Innovations | All Rights Reserved",
    policyLinks: [
      { href: "/terms", text: "Terms" },
      { href: "/privacy-policy", text: "Privacy Policy" },
      
    ],
  },
};
