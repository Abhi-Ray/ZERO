// Services page : testimonial section

export const testimonials = [
  {
    heading: "Amazing Support",
    quote: "The support from the team was exceptional! Our project exceeded expectations and delivered real value.",
    name: "Priya Desai",
    title: "COO, NextGen Solutions",
    rating: 5,
  },
  {
    heading: "Great Collaboration",
    quote: "Working with them was a smooth and rewarding experience. Their expertise and dedication were impressive.",
    name: "Arjun Verma",
    title: "Creative Head, PixelCraft Studios",
    rating: 4,
  },
  {
    heading: "Excellent Performance",
    quote: "The results were extraordinary, and our business has reached new heights thanks to their hard work.",
    name: "Meera Kapoor",
    title: "Founder, BrightFuture Startups",
    rating: 5,
  },
  {
    heading: "Highly Recommended",
    quote: "Their dedication and focus on results were truly impressive. I couldn't have asked for a better partner.",
    name: "Vikram Nair",
    title: "Director, AlphaTech Industries",
    rating: 4,
  },
  {
    heading: "Top-Notch Quality",
    quote: "Every detail was handled with the utmost care. The quality of their work speaks for itself.",
    name: "Nisha Iyer",
    title: "Head of Operations, Creative Minds",
    rating: 5,
  },
];
