// service page : All services section 

export const service = [
    {
      icon: "FaDesktop",
      title: "Website Development",
      description: "Creative and visually stunning design solutions to make your brand stand out.",
      href: "/Website Development",
    },
    {
      icon: "FaPalette",
      title: "Graphic Designing",
      description: "Cutting-edge technology solutions to drive your business forward.",
      href: "/Graphic Designing",
    },
    {
      icon: "FaCode",
      title: "UI/UX Web Designing",
      description: "Strategic marketing services to enhance your brand's reach and impact.",
      href: "/UI/UX Web Designing",
    },
    {
      icon: "FaBullhorn",
      title: "Brand Building",
      description: "Creative and visually stunning design solutions to make your brand stand out.",
      href: "/Brand Building",
    },
    {
      icon: "FaShareSquare",
      title: "Social Media Handling",
      description: "Cutting-edge technology solutions to drive your business forward.",
      href: "/Social Media Handling",
    },
    {
      icon: "FaComments",
      title: "Business Consultation",
      description: "Strategic marketing services to enhance your brand's reach and impact.",
      href: "/Business Consultation",
    },
    {
      icon: "FaEdit",
      title: "SEO and Content Writing",
      description: "Strategic marketing services to enhance your brand's reach and impact.",
      href: "/SEO and Content Writing",
    },
    {
      icon: "FaChartLine",
      title: "Digital Marketing",
      description: "Strategic marketing services to enhance your brand's reach and impact.",
      href: "/Digital Marketing",
    }
  ];