import { FaLaptopCode, FaPaintBrush,FaBullhorn,FaMoneyBillAlt, FaChartLine} from "react-icons/fa";

//  Categories section
export const Job = [
    {
      name: "Design",
      href: "/design",
      icon: FaPaintBrush,
      delay: 0.1,
    },
    {
      name: "Technology",
      href: "/technology",
      icon: FaLaptopCode,
      delay: 0.2,
    },
    {
      name: "Marketing",
      href: "/marketing",
      icon: FaBullhorn,
      delay: 0.3,
    },
    {
      name: "Finance",
      href: "/finance",
      icon: FaMoneyBillAlt,
      delay: 0.4,
    },
    {
      name: "Sales",
      href: "/sales",
      icon: FaChartLine,
      delay: 0.5,
    },
  ];