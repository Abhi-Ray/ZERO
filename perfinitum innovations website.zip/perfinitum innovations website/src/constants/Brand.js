
  //  brand 
  export const brandImages = [
    "/Images/brand-1.png",
    "/Images/brand-2.png",
    "/Images/brand-3.jpg",
    "/Images/brand-4.webp",
    "/Images/brand-5.webp",
    "/Images/brand-6.png",
  ];
  
  export  const brandImages1 = [
    "/Images/brand-7.webp",
    "/Images/brand-8.png",
    "/Images/brand-9.jpg",
    "/Images/brand-10.png",
    "/Images/brand-11.png",
    "/Images/brand-12.webp",
  ];